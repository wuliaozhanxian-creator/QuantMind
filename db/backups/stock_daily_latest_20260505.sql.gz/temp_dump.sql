--
-- PostgreSQL database dump
--

\restrict mDINxzbrtAsaMBThL0JkzrJFsmvl0gtetNsPzhQbEc6G3nVZSiGR5jRZnjZkZjE

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: stock_daily_latest; Type: TABLE; Schema: public; Owner: quantmind
--

CREATE TABLE public.stock_daily_latest (
    trade_date date NOT NULL,
    symbol character varying(32) NOT NULL,
    stock_name text,
    open double precision,
    high double precision,
    low double precision,
    close double precision,
    volume double precision,
    amount double precision,
    pct_change double precision,
    turnover_rate double precision,
    pe_ttm double precision,
    pb double precision,
    total_mv double precision,
    float_mv double precision,
    listed_days integer,
    is_st smallint,
    listing_market character varying(16),
    industry text,
    province text,
    consecutive_limit_up_days integer,
    limit_up_today smallint,
    limit_down_today smallint,
    return_1d double precision,
    return_3d double precision,
    return_5d double precision,
    return_10d double precision,
    return_20d double precision,
    return_60d double precision,
    ma5 double precision,
    ma10 double precision,
    ma20 double precision,
    ma60 double precision,
    ma_gap_5 double precision,
    ma_gap_10 double precision,
    ma_gap_20 double precision,
    rsi_6 double precision,
    rsi_14 double precision,
    kdj_k double precision,
    kdj_d double precision,
    kdj_j double precision,
    macd_dif double precision,
    macd_dea double precision,
    macd_hist double precision,
    vol_std_5 double precision,
    vol_std_20 double precision,
    vol_std_60 double precision,
    vol_atr_14 double precision,
    volume_ratio_5 double precision,
    volume_ratio_20 double precision,
    volume_ma_5 double precision,
    amount_ma_5 double precision,
    bp double precision,
    ep_ttm double precision,
    ln_mv_total double precision,
    beta_20 double precision,
    label double precision,
    ind_code_l1 text,
    ind_code_l2 text,
    micro_effective_spread double precision,
    micro_imbalance_volume double precision,
    micro_jump_flag smallint,
    roe double precision,
    volume_trend_3d boolean,
    adj_factor double precision DEFAULT 1.0,
    volume_ma_3 double precision,
    idx_all integer DEFAULT 1,
    idx_hs300 integer DEFAULT 0,
    idx_zz1000 integer DEFAULT 0,
    idx_margin integer DEFAULT 0,
    concept_ai integer DEFAULT 0,
    concept_chip integer DEFAULT 0,
    concept_new_energy integer DEFAULT 0,
    concept_pv integer DEFAULT 0,
    concept_military integer DEFAULT 0,
    concept_medical integer DEFAULT 0,
    concept_fintech integer DEFAULT 0,
    concept_consumption integer DEFAULT 0,
    concept_state_owned integer DEFAULT 0,
    main_flow double precision,
    inst_ownership double precision,
    profit_growth double precision,
    idx_chinext integer DEFAULT 1,
    lrg_trd_tolbuynum double precision,
    lrg_trd_tolsellnum double precision,
    flow_net_amount double precision,
    b_volume double precision,
    s_volume double precision,
    concept_lithium integer DEFAULT 0
)
PARTITION BY RANGE (trade_date);


ALTER TABLE public.stock_daily_latest OWNER TO quantmind;

--
-- Name: TABLE stock_daily_latest; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON TABLE public.stock_daily_latest IS '股票日线行情最新数据（分区表），包含行情、技术指标、基本面、概念标签等综合字段';


--
-- Name: COLUMN stock_daily_latest.trade_date; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.trade_date IS '交易日期';


--
-- Name: COLUMN stock_daily_latest.symbol; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.symbol IS '股票代码（前缀格式，如 SH600000）';


--
-- Name: COLUMN stock_daily_latest.stock_name; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.stock_name IS '股票名称';


--
-- Name: COLUMN stock_daily_latest.open; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.open IS '开盘价（后复权）';


--
-- Name: COLUMN stock_daily_latest.high; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.high IS '最高价（后复权）';


--
-- Name: COLUMN stock_daily_latest.low; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.low IS '最低价（后复权）';


--
-- Name: COLUMN stock_daily_latest.close; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.close IS '收盘价（后复权）';


--
-- Name: COLUMN stock_daily_latest.volume; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.volume IS '成交量（手）';


--
-- Name: COLUMN stock_daily_latest.amount; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.amount IS '成交额（元）';


--
-- Name: COLUMN stock_daily_latest.pct_change; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.pct_change IS '涨跌幅（百分比数值，如 -0.65 表示 -0.65%）';


--
-- Name: COLUMN stock_daily_latest.turnover_rate; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.turnover_rate IS '换手率（%）';


--
-- Name: COLUMN stock_daily_latest.pe_ttm; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.pe_ttm IS '市盈率 TTM';


--
-- Name: COLUMN stock_daily_latest.pb; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.pb IS '市净率';


--
-- Name: COLUMN stock_daily_latest.total_mv; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.total_mv IS '总市值（元）';


--
-- Name: COLUMN stock_daily_latest.float_mv; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.float_mv IS '流通市值（元）';


--
-- Name: COLUMN stock_daily_latest.listed_days; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.listed_days IS '上市天数';


--
-- Name: COLUMN stock_daily_latest.is_st; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.is_st IS '是否 ST 股（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.listing_market; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.listing_market IS '上市市场（SH/SZ/BJ）';


--
-- Name: COLUMN stock_daily_latest.industry; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.industry IS '所属行业（申万一级）';


--
-- Name: COLUMN stock_daily_latest.province; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.province IS '所属省份';


--
-- Name: COLUMN stock_daily_latest.consecutive_limit_up_days; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.consecutive_limit_up_days IS '连续涨停天数';


--
-- Name: COLUMN stock_daily_latest.limit_up_today; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.limit_up_today IS '今日是否涨停（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.limit_down_today; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.limit_down_today IS '今日是否跌停（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.return_1d; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.return_1d IS '次日收益率（小数比例，如 0.05 表示 5%）';


--
-- Name: COLUMN stock_daily_latest.return_3d; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.return_3d IS '3日收益率（小数比例）';


--
-- Name: COLUMN stock_daily_latest.return_5d; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.return_5d IS '5日收益率（小数比例）';


--
-- Name: COLUMN stock_daily_latest.return_10d; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.return_10d IS '10日收益率（小数比例）';


--
-- Name: COLUMN stock_daily_latest.return_20d; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.return_20d IS '20日收益率（小数比例）';


--
-- Name: COLUMN stock_daily_latest.return_60d; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.return_60d IS '60日收益率（小数比例）';


--
-- Name: COLUMN stock_daily_latest.ma5; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ma5 IS '5日均线';


--
-- Name: COLUMN stock_daily_latest.ma10; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ma10 IS '10日均线';


--
-- Name: COLUMN stock_daily_latest.ma20; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ma20 IS '20日均线';


--
-- Name: COLUMN stock_daily_latest.ma60; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ma60 IS '60日均线';


--
-- Name: COLUMN stock_daily_latest.ma_gap_5; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ma_gap_5 IS '5日乖离率（%）';


--
-- Name: COLUMN stock_daily_latest.ma_gap_10; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ma_gap_10 IS '10日乖离率（%）';


--
-- Name: COLUMN stock_daily_latest.ma_gap_20; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ma_gap_20 IS '20日乖离率（%）';


--
-- Name: COLUMN stock_daily_latest.rsi_6; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.rsi_6 IS 'RSI 6日指标';


--
-- Name: COLUMN stock_daily_latest.rsi_14; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.rsi_14 IS 'RSI 14日指标';


--
-- Name: COLUMN stock_daily_latest.kdj_k; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.kdj_k IS 'KDJ K值';


--
-- Name: COLUMN stock_daily_latest.kdj_d; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.kdj_d IS 'KDJ D值';


--
-- Name: COLUMN stock_daily_latest.kdj_j; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.kdj_j IS 'KDJ J值';


--
-- Name: COLUMN stock_daily_latest.macd_dif; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.macd_dif IS 'MACD DIF值';


--
-- Name: COLUMN stock_daily_latest.macd_dea; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.macd_dea IS 'MACD DEA值';


--
-- Name: COLUMN stock_daily_latest.macd_hist; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.macd_hist IS 'MACD 柱状值';


--
-- Name: COLUMN stock_daily_latest.vol_std_5; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.vol_std_5 IS '5日波动率';


--
-- Name: COLUMN stock_daily_latest.vol_std_20; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.vol_std_20 IS '20日波动率';


--
-- Name: COLUMN stock_daily_latest.vol_std_60; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.vol_std_60 IS '60日波动率';


--
-- Name: COLUMN stock_daily_latest.vol_atr_14; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.vol_atr_14 IS '14日 ATR（平均真实波幅）';


--
-- Name: COLUMN stock_daily_latest.volume_ratio_5; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.volume_ratio_5 IS '5日量比';


--
-- Name: COLUMN stock_daily_latest.volume_ratio_20; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.volume_ratio_20 IS '20日量比';


--
-- Name: COLUMN stock_daily_latest.volume_ma_5; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.volume_ma_5 IS '5日成交量均线';


--
-- Name: COLUMN stock_daily_latest.amount_ma_5; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.amount_ma_5 IS '5日成交额均线';


--
-- Name: COLUMN stock_daily_latest.bp; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.bp IS '账面市值比';


--
-- Name: COLUMN stock_daily_latest.ep_ttm; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ep_ttm IS '盈利收益率 TTM（1/PE）';


--
-- Name: COLUMN stock_daily_latest.ln_mv_total; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ln_mv_total IS '总市值对数';


--
-- Name: COLUMN stock_daily_latest.beta_20; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.beta_20 IS '20日 Beta 值';


--
-- Name: COLUMN stock_daily_latest.label; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.label IS '标签（用于机器学习）';


--
-- Name: COLUMN stock_daily_latest.ind_code_l1; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ind_code_l1 IS '一级行业代码';


--
-- Name: COLUMN stock_daily_latest.ind_code_l2; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.ind_code_l2 IS '二级行业代码';


--
-- Name: COLUMN stock_daily_latest.micro_effective_spread; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.micro_effective_spread IS '微观结构：有效价差';


--
-- Name: COLUMN stock_daily_latest.micro_imbalance_volume; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.micro_imbalance_volume IS '微观结构：成交量不平衡';


--
-- Name: COLUMN stock_daily_latest.micro_jump_flag; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.micro_jump_flag IS '微观结构：跳跃标志（0/1）';


--
-- Name: COLUMN stock_daily_latest.roe; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.roe IS '净资产收益率 ROE（小数比例）';


--
-- Name: COLUMN stock_daily_latest.volume_trend_3d; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.volume_trend_3d IS '3日成交量递增标志';


--
-- Name: COLUMN stock_daily_latest.adj_factor; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.adj_factor IS '复权因子';


--
-- Name: COLUMN stock_daily_latest.volume_ma_3; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.volume_ma_3 IS '3日成交量均线';


--
-- Name: COLUMN stock_daily_latest.idx_all; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.idx_all IS '全市场指数成分（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.idx_hs300; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.idx_hs300 IS '沪深300成分（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.idx_zz1000; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.idx_zz1000 IS '中证1000成分（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.idx_margin; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.idx_margin IS '融资融券标的（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.concept_ai; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.concept_ai IS 'AI 概念（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.concept_chip; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.concept_chip IS '芯片概念（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.concept_new_energy; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.concept_new_energy IS '新能源概念（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.concept_pv; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.concept_pv IS '光伏概念（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.concept_military; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.concept_military IS '军工概念（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.concept_medical; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.concept_medical IS '医药概念（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.concept_fintech; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.concept_fintech IS '金融科技概念（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.concept_consumption; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.concept_consumption IS '消费概念（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.concept_state_owned; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.concept_state_owned IS '国企改革概念（0=否，1=是）';


--
-- Name: COLUMN stock_daily_latest.main_flow; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.main_flow IS '主力净流入（元）';


--
-- Name: COLUMN stock_daily_latest.inst_ownership; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.inst_ownership IS '机构持股比例（%）';


--
-- Name: COLUMN stock_daily_latest.profit_growth; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.profit_growth IS '利润增长率（%）';


--
-- Name: COLUMN stock_daily_latest.idx_chinext; Type: COMMENT; Schema: public; Owner: quantmind
--

COMMENT ON COLUMN public.stock_daily_latest.idx_chinext IS '创业板指数成分（0=否，1=是）';


--
-- Name: stock_daily_latest stock_daily_new_pkey; Type: CONSTRAINT; Schema: public; Owner: quantmind
--

ALTER TABLE ONLY public.stock_daily_latest
    ADD CONSTRAINT stock_daily_new_pkey PRIMARY KEY (trade_date, symbol);


--
-- Name: idx_sdl_symbol_date; Type: INDEX; Schema: public; Owner: quantmind
--

CREATE INDEX idx_sdl_symbol_date ON ONLY public.stock_daily_latest USING btree (symbol, trade_date);


--
-- Name: stock_daily_new_symbol_idx; Type: INDEX; Schema: public; Owner: quantmind
--

CREATE INDEX stock_daily_new_symbol_idx ON ONLY public.stock_daily_latest USING btree (symbol);


--
-- Name: stock_daily_new_trade_date_idx; Type: INDEX; Schema: public; Owner: quantmind
--

CREATE INDEX stock_daily_new_trade_date_idx ON ONLY public.stock_daily_latest USING btree (trade_date);


--
-- PostgreSQL database dump complete
--

\unrestrict mDINxzbrtAsaMBThL0JkzrJFsmvl0gtetNsPzhQbEc6G3nVZSiGR5jRZnjZkZjE

